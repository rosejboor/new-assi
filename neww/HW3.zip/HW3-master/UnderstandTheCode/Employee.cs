﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderstandTheCode
{
    public class Employee
    {
        public int EmployeeId { get; set; }

        public Employee()
        {
            // This code will be executed whenever a new object is created
        }

        public string PrintEmployeeReport()
        {
            return "";
        }
    }
}
